package com.kpmg.ehs.constants;

/**
 * @author 91901
 */
public class EHS_MainPortletKeys {

	public static final String EHS_MAIN =
		"com_kpmg_ehs_EHS_MainPortlet";

}